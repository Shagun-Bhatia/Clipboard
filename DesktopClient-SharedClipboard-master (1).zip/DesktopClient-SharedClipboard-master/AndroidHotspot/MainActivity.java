package com.snu.shagunbhatia.wkjhgfdfghj;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.*;
import android.net.wifi.*;
import java.lang.reflect.*;
import java.lang.reflect.Method;

import android.content.Context;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        WifiManager wifimanager = (WifiManager) this.getSystemService(MainActivity.WIFI_SERVICE);
        WifiConfiguration wificonfiguration = null;

                try {

                    wifimanager.setWifiEnabled(false);


                    Method method = wifimanager.getClass().getMethod("setWifiApEnabled", WifiConfiguration.class, boolean.class);
                    method.invoke(wifimanager, wificonfiguration, true);

                }
                catch (Exception e) {
                    e.printStackTrace();

                }


    }
}
